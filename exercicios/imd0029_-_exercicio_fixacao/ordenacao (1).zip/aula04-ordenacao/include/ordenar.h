#include <string>

using namespace std;

void ordenar(string array[], int tamanho);