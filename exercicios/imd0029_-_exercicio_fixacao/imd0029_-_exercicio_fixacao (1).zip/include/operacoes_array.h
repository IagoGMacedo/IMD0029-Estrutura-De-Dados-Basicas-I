int soma(int array[], int tamanho);
int min(int array[], int tamanho);