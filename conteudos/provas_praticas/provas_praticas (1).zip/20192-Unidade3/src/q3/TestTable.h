//
//  TestTable.hpp
//
//  Created by Eiji Adachi Medeiros Barbosa 
//

#ifndef TestTable_h
#define TestTable_h

bool testar_Ajustar();
bool testar_Construtor();

#endif /* TestTable_h */
