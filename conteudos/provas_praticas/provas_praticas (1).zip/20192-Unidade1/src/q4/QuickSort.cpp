#include "Sort.h"
#include <iostream>

inline void swap(int& a, int& b)
{
	int aux = a;
	a = b;
	b = aux;
}

void sort(int v[], int size)
{
}
