#include "Search.h"

int bitonicSearch(int a[], int size, int k)
{
	//TODO - Implementar aqui
	return -1;
}