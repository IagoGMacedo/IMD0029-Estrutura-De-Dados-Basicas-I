
bool soma3(int[], int, int);