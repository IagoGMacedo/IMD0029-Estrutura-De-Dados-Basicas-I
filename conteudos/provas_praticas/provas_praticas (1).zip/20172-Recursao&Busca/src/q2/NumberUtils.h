#include <string>

using namespace std;

string fromDecToBin(int);