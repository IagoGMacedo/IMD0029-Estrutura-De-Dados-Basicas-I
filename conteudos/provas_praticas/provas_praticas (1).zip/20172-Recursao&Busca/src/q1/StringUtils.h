#include <string>

using namespace std;

string revert(string);