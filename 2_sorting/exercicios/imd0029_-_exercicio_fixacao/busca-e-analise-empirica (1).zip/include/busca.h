#include <string>
using namespace std;
int busca(string array[], int tamanho, string chave);